<?php

  $servername = "localhost";
  $username   ="tumainir_jitwebs";
  $password   ="BBIT/7949/1/1694";
  $dbname     ="tumainir_loan";


  //connect to the database
 $conn =  mysqli_connect($servername,$username,$password,$dbname);


//checking the connecion
 if (!$conn) { 
 	"connection failed" . mysqli_connect_error();
 	
 }


?>