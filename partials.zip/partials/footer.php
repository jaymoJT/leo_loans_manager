<footer class="main-footer">
    <strong>Copyright &copy; 2019 <a href="#">My system</a>.</strong> All rights
    reserved.
</footer>
</body>
</html>